package com.example.muhasebeapp

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TransactionsActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recycler: RecyclerView
    private var userId: Int = -1

    // Kategoriler
    val categories = arrayOf("yemek", "eğlence", "barınma", "ulaşım", "hobi", "giyim", "sağlık", "eğitim", "sigara", "girdi", "borç", "diğer")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transactions)

        userId = intent.getIntExtra("USER_ID", -1)
        dbHelper = DatabaseHelper(this)
        recycler = findViewById(R.id.recyclerTransactions) // XML'deki ID'ye dikkat et

        recycler.layoutManager = LinearLayoutManager(this)

        // Verileri Yükle
        loadData()
    }

    private fun loadData() {
        // Tüm işlemleri çekiyoruz (veya tarih filtresi ekleyebilirsin)
        val list = dbHelper.getAllTransactions(userId)

        // DÜZELTİLEN KISIM: Adaptöre tıklama fonksiyonunu gönderiyoruz
        recycler.adapter = TransactionAdapter(list) { selectedTransaction ->
            showEditDialog(selectedTransaction)
        }
    }

    // Düzenleme/Silme Penceresini Açan Fonksiyon
    private fun showEditDialog(transaction: Transaction) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_transaction, null)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)

        val dialog = builder.create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()

        // View Elemanları
        val edtDesc = dialogView.findViewById<EditText>(R.id.editDialogDesc)
        val edtAmount = dialogView.findViewById<EditText>(R.id.editDialogAmount)
        val spinner = dialogView.findViewById<Spinner>(R.id.editDialogSpinner)
        val rbIncome = dialogView.findViewById<RadioButton>(R.id.rbEditIncome)
        val rbExpense = dialogView.findViewById<RadioButton>(R.id.rbEditExpense)
        val btnUpdate = dialogView.findViewById<Button>(R.id.btnUpdate)
        val btnDelete = dialogView.findViewById<Button>(R.id.btnDelete)

        // Spinner Doldur
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinner.adapter = adapter

        // Mevcut Verileri Yerleştir
        edtDesc.setText(transaction.desc)
        edtAmount.setText(transaction.amount.toString())

        val catPosition = categories.indexOf(transaction.category)
        if (catPosition >= 0) spinner.setSelection(catPosition)

        if (transaction.type == "girdi") rbIncome.isChecked = true else rbExpense.isChecked = true

        // --- GÜNCELLEME ---
        btnUpdate.setOnClickListener {
            val newDesc = edtDesc.text.toString()
            val newAmountStr = edtAmount.text.toString()
            val newCategory = spinner.selectedItem.toString()
            val newType = if (rbIncome.isChecked) "girdi" else "cıktı"

            if (newDesc.isNotEmpty() && newAmountStr.isNotEmpty()) {
                val newAmount = newAmountStr.toDouble()
                dbHelper.updateTransaction(transaction.id, transaction.date, newCategory, newDesc, newAmount, newType)
                Toast.makeText(this, "Güncellendi", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                loadData() // Listeyi Yenile
            }
        }

        // --- SİLME ---
        btnDelete.setOnClickListener {
            dbHelper.deleteTransaction(transaction.id)
            Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            loadData() // Listeyi Yenile
        }
    }
}