package com.example.muhasebeapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

// Tıklama olayını ana sayfaya bildirmek için bir interface
class PeriodAdapter(
    private val periods: List<PeriodSummary>,
    private val onClick: (PeriodSummary) -> Unit
) : RecyclerView.Adapter<PeriodAdapter.PeriodViewHolder>() {

    class PeriodViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtDate: TextView = view.findViewById(R.id.txtPeriodDate)
        val txtBalance: TextView = view.findViewById(R.id.txtPeriodBalance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeriodViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_period, parent, false)
        return PeriodViewHolder(view)
    }

    override fun onBindViewHolder(holder: PeriodViewHolder, position: Int) {
        val item = periods[position]

        // Tarihleri güzelleştir (yyyy-MM-dd -> dd.MM.yyyy)
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outputFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

        val start = inputFormat.parse(item.startDate)
        val end = inputFormat.parse(item.endDate)

        val dateText = "${outputFormat.format(start)} - ${outputFormat.format(end)}"
        holder.txtDate.text = dateText

        // Bakiyeyi Yaz
        if (item.netBalance >= 0) {
            holder.txtBalance.text = "+${item.netBalance} TL"
            holder.txtBalance.setTextColor(Color.parseColor("#4CAF50")) // Yeşil (veya beyaz üstüne yeşilimsi)
        } else {
            holder.txtBalance.text = "${item.netBalance} TL"
            holder.txtBalance.setTextColor(Color.parseColor("#FF5252")) // Kırmızımsı
        }

        // Tıklama Olayı
        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }

    override fun getItemCount() = periods.size
}