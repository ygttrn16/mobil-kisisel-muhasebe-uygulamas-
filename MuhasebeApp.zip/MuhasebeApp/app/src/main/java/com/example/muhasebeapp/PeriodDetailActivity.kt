package com.example.muhasebeapp

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PeriodDetailActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recycler: RecyclerView
    private var userId: Int = -1
    private var startDate: String = ""
    private var endDate: String = ""

    // Kategoriler (Spinner İçin)
    val categories = arrayOf("yemek", "eğlence", "barınma", "ulaşım", "hobi", "giyim", "sağlık", "eğitim", "sigara", "girdi", "borç", "diğer")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_period_detail)

        userId = intent.getIntExtra("USER_ID", -1)
        startDate = intent.getStringExtra("START_DATE") ?: ""
        endDate = intent.getStringExtra("END_DATE") ?: ""

        dbHelper = DatabaseHelper(this)
        recycler = findViewById(R.id.recyclerDetail)
        val title = findViewById<TextView>(R.id.txtDetailTitle)

        title.text = "Dönem: $startDate / $endDate"
        recycler.layoutManager = LinearLayoutManager(this)

        // Verileri Yükle
        loadData()
    }

    private fun loadData() {
        val list = dbHelper.getTransactionsByDateRange(userId, startDate, endDate)

        // Adaptöre tıklama fonksiyonunu (showEditDialog) gönderiyoruz
        recycler.adapter = TransactionAdapter(list) { selectedTransaction ->
            showEditDialog(selectedTransaction)
        }
    }

    private fun showEditDialog(transaction: Transaction) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_transaction, null)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)

        val dialog = builder.create()
        // Arka planı şeffaf yap ki CardView'ın köşeleri gözüksün
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()

        // View Elemanlarını Tanımla
        val edtDesc = dialogView.findViewById<EditText>(R.id.editDialogDesc)
        val edtAmount = dialogView.findViewById<EditText>(R.id.editDialogAmount)
        val spinner = dialogView.findViewById<Spinner>(R.id.editDialogSpinner)
        val rbGroup = dialogView.findViewById<RadioGroup>(R.id.editDialogRadioGroup)
        val rbExpense = dialogView.findViewById<RadioButton>(R.id.rbEditExpense)
        val rbIncome = dialogView.findViewById<RadioButton>(R.id.rbEditIncome)
        val btnUpdate = dialogView.findViewById<Button>(R.id.btnUpdate)
        val btnDelete = dialogView.findViewById<Button>(R.id.btnDelete)

        // Spinner Ayarla
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinner.adapter = adapter

        // Mevcut Verileri Doldur (Pre-fill)
        edtDesc.setText(transaction.desc)
        edtAmount.setText(transaction.amount.toString())

        // Kategoriyi seçili getir
        val catPosition = categories.indexOf(transaction.category)
        if (catPosition >= 0) spinner.setSelection(catPosition)

        // Tipi seçili getir
        if (transaction.type == "girdi") {
            rbIncome.isChecked = true
        } else {
            rbExpense.isChecked = true
        }

        // --- GÜNCELLE BUTONU ---
        btnUpdate.setOnClickListener {
            val newDesc = edtDesc.text.toString()
            val newAmountStr = edtAmount.text.toString()
            val newCategory = spinner.selectedItem.toString()
            val newType = if (rbIncome.isChecked) "girdi" else "cıktı"

            if (newDesc.isNotEmpty() && newAmountStr.isNotEmpty()) {
                val newAmount = newAmountStr.toDouble()

                // Veritabanında güncelle
                dbHelper.updateTransaction(transaction.id, transaction.date, newCategory, newDesc, newAmount, newType)

                Toast.makeText(this, "Kayıt Güncellendi", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                loadData() // Listeyi Yenile
            } else {
                Toast.makeText(this, "Boş alan bırakmayınız", Toast.LENGTH_SHORT).show()
            }
        }

        // --- SİL BUTONU ---
        btnDelete.setOnClickListener {
            // Emin misin diye sormak istersen buraya ikinci bir dialog koyabilirsin
            // Şimdilik direkt silelim
            dbHelper.deleteTransaction(transaction.id)
            Toast.makeText(this, "Kayıt Silindi", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            loadData() // Listeyi Yenile
        }
    }
}