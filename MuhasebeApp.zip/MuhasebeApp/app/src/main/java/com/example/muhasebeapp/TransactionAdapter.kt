package com.example.muhasebeapp

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// DİKKAT: Artık bir 'onClick' fonksiyonu alıyor
class TransactionAdapter(
    private val items: List<Transaction>,
    private val onClick: (Transaction) -> Unit // Tıklama Olayı Eklendi
) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtCategory: TextView = view.findViewById(R.id.textCategory)
        val txtDesc: TextView = view.findViewById(R.id.textDescription)
        val txtDate: TextView = view.findViewById(R.id.textDate)
        val txtAmount: TextView = view.findViewById(R.id.textAmount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.txtCategory.text = item.category
        holder.txtDesc.text = item.desc
        holder.txtDate.text = item.date

        if (item.type == "girdi") {
            holder.txtAmount.text = "+${item.amount} TL"
            holder.txtAmount.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            holder.txtAmount.text = "-${item.amount} TL"
            holder.txtAmount.setTextColor(Color.parseColor("#F44336"))
        }

        // TIKLAMA OLAYINI BAĞLA
        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }

    override fun getItemCount() = items.size
}