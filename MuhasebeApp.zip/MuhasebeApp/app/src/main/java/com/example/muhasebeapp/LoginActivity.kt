package com.example.muhasebeapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.muhasebeapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var dbHelper: DatabaseHelper

    // Varsayılan mod: Giriş (false = kayıt ol modu)
    private var isLoginMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)

        // Butona basılınca (Giriş veya Kayıt)
        binding.btnAction.setOnClickListener {
            val username = binding.edtUsername.text.toString().trim()
            val password = binding.edtPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Lütfen alanları doldurun", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (isLoginMode) {
                // --- GİRİŞ YAPMA KISMI ---
                val userId = dbHelper.checkUser(username, password)
                if (userId != -1) {
                    val intent = Intent(this, SplashActivity::class.java)
                    intent.putExtra("TARGET", "MAIN") // Hedef Ana Ekran
                    intent.putExtra("USER_ID", userId)
                    intent.putExtra("USERNAME", username)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Hatalı kullanıcı adı veya şifre", Toast.LENGTH_SHORT).show()
                }
            } else {
                // --- KAYIT OLMA KISMI ---
                val success = dbHelper.registerUser(username, password)
                if (success) {
                    Toast.makeText(this, "Kayıt Başarılı! Şimdi giriş yapın.", Toast.LENGTH_LONG).show()
                    toggleMode() // Otomatik giriş ekranına dön
                } else {
                    Toast.makeText(this, "Bu kullanıcı adı zaten alınmış.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // "Hesabın yok mu?" yazısına tıklayınca modu değiştir
        binding.txtSwitchMode.setOnClickListener {
            toggleMode()
        }
    }

    private fun toggleMode() {
        isLoginMode = !isLoginMode
        if (isLoginMode) {
            binding.txtTitle.text = "Giriş Yap"
            binding.btnAction.text = "GİRİŞ YAP"
            binding.txtSwitchMode.text = "Hesabın yok mu? Kayıt Ol"
        } else {
            binding.txtTitle.text = "Kayıt Ol"
            binding.btnAction.text = "KAYIT OL"
            binding.txtSwitchMode.text = "Zaten hesabın var mı? Giriş Yap"
        }
    }
}