package com.example.muhasebeapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Temayı Ayarla
        val sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("DarkMode", false)

        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        setContentView(R.layout.activity_splash)

        // 2. Gelen Verileri Al
        val targetDestination = intent.getStringExtra("TARGET") ?: "LOGIN"
        val userId = intent.getIntExtra("USER_ID", -1)
        val username = intent.getStringExtra("USERNAME")

        // Tarih verileri (Sadece Transactions için gerekli ama burada alıyoruz)
        val startDate = intent.getStringExtra("START_DATE")
        val endDate = intent.getStringExtra("END_DATE")

        Handler(Looper.getMainLooper()).postDelayed({

            val nextIntent = when (targetDestination) {

                // Ana Sayfaya Git
                "MAIN" -> Intent(this, MainActivity::class.java).apply {
                    putExtra("USER_ID", userId)
                    putExtra("USERNAME", username)
                }

                // Giriş Ekranına Git
                "LOGIN" -> Intent(this, LoginActivity::class.java)

                // Ayarlara Git
                "SETTINGS" -> Intent(this, SettingsActivity::class.java)

                // Dönem Hareketlerine Git (ÖNEMLİ: PeriodDetailActivity kullanıyoruz ve tarihleri iletiyoruz)
                "TRANSACTIONS" -> Intent(this, PeriodDetailActivity::class.java).apply {
                    putExtra("USER_ID", userId)
                    putExtra("START_DATE", startDate)
                    putExtra("END_DATE", endDate)
                }

                // Geçmişe Git
                "HISTORY" -> Intent(this, HistoryActivity::class.java).apply {
                    putExtra("USER_ID", userId)
                }

                // Analize Git
                "ANALYSIS" -> Intent(this, AnalysisActivity::class.java).apply {
                    putExtra("USER_ID", userId)
                }

                else -> Intent(this, LoginActivity::class.java)
            }

            startActivity(nextIntent)
            finish()
        }, 2000) // 2 saniye bekle
    }
}