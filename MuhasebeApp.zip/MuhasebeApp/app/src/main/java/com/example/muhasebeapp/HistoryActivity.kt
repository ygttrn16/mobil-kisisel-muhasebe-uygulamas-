package com.example.muhasebeapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val userId = intent.getIntExtra("USER_ID", -1)
        val dbHelper = DatabaseHelper(this)
        val recycler = findViewById<RecyclerView>(R.id.recyclerHistory)

        // Ayarlardan "Başlangıç Günü"nü al (1 veya 15)
        val prefs = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val startDay = prefs.getInt("StartDay", 15)

        // Veritabanından Dönem Özetlerini Çek
        val periods = dbHelper.getPeriodSummaries(userId, startDay)

        if (periods.isEmpty()) {
            Toast.makeText(this, "Henüz geçmiş dönem kaydı yok.", Toast.LENGTH_SHORT).show()
        }

        recycler.layoutManager = LinearLayoutManager(this)

        // Adaptörü bağla ve tıklanınca Detay sayfasına git
        recycler.adapter = PeriodAdapter(periods) { selectedPeriod ->
            // Tıklanan dönemin detayına git
            val intent = Intent(this, PeriodDetailActivity::class.java)
            intent.putExtra("USER_ID", userId)
            intent.putExtra("START_DATE", selectedPeriod.startDate)
            intent.putExtra("END_DATE", selectedPeriod.endDate)
            startActivity(intent)
        }
    }
}