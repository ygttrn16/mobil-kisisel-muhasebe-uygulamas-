package com.example.muhasebeapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

// İşlem Modeli
data class Transaction(
    val id: Int,
    val date: String,
    val category: String,
    val desc: String,
    val amount: Double,
    val type: String
)

// Dönem Özeti Modeli
data class PeriodSummary(
    val startDate: String,
    val endDate: String,
    val netBalance: Double
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "MuhasebeProDB", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        val createUserTable = "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)"
        db.execSQL(createUserTable)

        val createTransactionTable = "CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, date TEXT, category TEXT, description TEXT, amount REAL, type TEXT)"
        db.execSQL(createTransactionTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS transactions")
        onCreate(db)
    }

    // --- KULLANICI İŞLEMLERİ ---
    fun registerUser(username: String, pass: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put("username", username)
        values.put("password", pass)
        val result = db.insert("users", null, values)
        return result != -1L
    }

    fun checkUser(username: String, pass: String): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT id FROM users WHERE username=? AND password=?", arrayOf(username, pass))
        var userId = -1
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0)
        }
        cursor.close()
        return userId
    }

    // --- HARCAMA İŞLEMLERİ ---
    fun addTransaction(userId: Int, date: String, category: String, desc: String, amount: Double, type: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("user_id", userId)
        contentValues.put("date", date)
        contentValues.put("category", category)
        contentValues.put("description", desc)
        contentValues.put("amount", amount)
        contentValues.put("type", type)
        val result = db.insert("transactions", null, contentValues)
        return result != -1L
    }

    // GÜNCELLENEN KISIM BURASI: id DESC eklendi
    fun getTransactionsByDateRange(userId: Int, startDate: String, endDate: String): ArrayList<Transaction> {
        val list = ArrayList<Transaction>()
        val db = this.readableDatabase

        // DİKKAT: "ORDER BY date DESC, id DESC" yaptık.
        // Böylece aynı gün eklenenlerde en son eklenen (ID'si büyük olan) en üstte çıkar.
        val cursor = db.rawQuery(
            "SELECT * FROM transactions WHERE user_id=? AND date >= ? AND date <= ? ORDER BY date DESC, id DESC",
            arrayOf(userId.toString(), startDate, endDate)
        )
        parseTransactions(cursor, list)
        cursor.close()
        return list
    }

    // YENİ: Tüm işlemleri getir
    fun getAllTransactions(userId: Int): ArrayList<Transaction> {
        val list = ArrayList<Transaction>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM transactions WHERE user_id=? ORDER BY date DESC, id DESC", arrayOf(userId.toString()))
        parseTransactions(cursor, list)
        cursor.close()
        return list
    }

    private fun parseTransactions(cursor: Cursor, list: ArrayList<Transaction>) {
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(0)
                val date = cursor.getString(2)
                val cat = cursor.getString(3)
                val desc = cursor.getString(4)
                val amt = cursor.getDouble(5)
                val type = cursor.getString(6)
                list.add(Transaction(id, date, cat, desc, amt, type))
            } while (cursor.moveToNext())
        }
    }

    // Dönem Özetleri
    fun getPeriodSummaries(userId: Int, startDayOfMonth: Int): ArrayList<PeriodSummary> {
        val summaries = ArrayList<PeriodSummary>()
        val db = this.readableDatabase

        val dateCursor = db.rawQuery("SELECT MIN(date), MAX(date) FROM transactions WHERE user_id=?", arrayOf(userId.toString()))
        if (!dateCursor.moveToFirst() || dateCursor.isNull(0)) {
            dateCursor.close()
            return summaries
        }
        val minDateStr = dateCursor.getString(0)
        val maxDateStr = dateCursor.getString(1)
        dateCursor.close()

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val minDate = sdf.parse(minDateStr) ?: Date()
        val maxDate = sdf.parse(maxDateStr) ?: Date()

        val calendar = Calendar.getInstance()
        calendar.time = minDate

        if (calendar.get(Calendar.DAY_OF_MONTH) >= startDayOfMonth) {
            calendar.set(Calendar.DAY_OF_MONTH, startDayOfMonth)
        } else {
            calendar.add(Calendar.MONTH, -1)
            calendar.set(Calendar.DAY_OF_MONTH, startDayOfMonth)
        }

        val currentCalendar = Calendar.getInstance()
        currentCalendar.time = maxDate
        if (currentCalendar.get(Calendar.DAY_OF_MONTH) >= startDayOfMonth) {
            currentCalendar.add(Calendar.MONTH, 1)
            currentCalendar.set(Calendar.DAY_OF_MONTH, startDayOfMonth)
        } else {
            currentCalendar.set(Calendar.DAY_OF_MONTH, startDayOfMonth)
        }
        val finalEndDate = currentCalendar.time

        while (calendar.time.before(finalEndDate)) {
            val periodStart = calendar.time
            val startDateStr = sdf.format(periodStart)

            calendar.add(Calendar.MONTH, 1)
            val periodEnd = calendar.time
            val endDateStr = sdf.format(periodEnd)

            val balanceCursor = db.rawQuery("""
                SELECT 
                    SUM(CASE WHEN type = 'girdi' THEN amount ELSE 0 END) as totalIncome,
                    SUM(CASE WHEN type = 'cıktı' THEN amount ELSE 0 END) as totalExpense
                FROM transactions 
                WHERE user_id=? AND date >= ? AND date < ?
            """, arrayOf(userId.toString(), startDateStr, endDateStr))

            if (balanceCursor.moveToFirst()) {
                val income = balanceCursor.getDouble(0)
                val expense = balanceCursor.getDouble(1)
                val net = income - expense
                if (income > 0 || expense > 0) {
                    summaries.add(PeriodSummary(startDateStr, endDateStr, net))
                }
            }
            balanceCursor.close()
        }
        summaries.reverse()
        return summaries
    }

    // Kaydı Sil
    fun deleteTransaction(id: Int): Boolean {
        val db = this.writableDatabase
        val result = db.delete("transactions", "id=?", arrayOf(id.toString()))
        return result > 0
    }

    // Kaydı Güncelle
    fun updateTransaction(id: Int, date: String, category: String, desc: String, amount: Double, type: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("date", date)
        contentValues.put("category", category)
        contentValues.put("description", desc)
        contentValues.put("amount", amount)
        contentValues.put("type", type)

        val result = db.update("transactions", contentValues, "id=?", arrayOf(id.toString()))
        return result > 0
    }
}