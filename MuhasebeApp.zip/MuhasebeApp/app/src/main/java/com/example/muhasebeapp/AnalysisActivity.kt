package com.example.muhasebeapp

import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.text.SimpleDateFormat
import java.util.*

class AnalysisActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analysis)

        val userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            finish()
            return
        }

        val dbHelper = DatabaseHelper(this)
        val sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)

        val txtTotal = findViewById<TextView>(R.id.txtTotalAnalysis)
        val container = findViewById<LinearLayout>(R.id.layoutStatsContainer)

        // 1. ŞU ANKİ DÖNEMİN TARİHLERİNİ BUL
        val (startDate, endDate) = getCurrentPeriodDates(sharedPreferences)

        // 2. BU TARİH ARALIĞINDAKİ İŞLEMLERİ ÇEK
        val transactionList = dbHelper.getTransactionsByDateRange(userId, startDate, endDate)

        // 3. KATEGORİLERE GÖRE GRUPLA
        val categoryMap = HashMap<String, Double>()
        var totalExpense = 0.0

        for (item in transactionList) {
            if (item.type == "cıktı") {
                val currentTotal = categoryMap.getOrDefault(item.category, 0.0)
                categoryMap[item.category] = currentTotal + item.amount
                totalExpense += item.amount
            }
        }

        // 4. EKRANA BAS
        txtTotal.text = "${totalExpense} TL"

        container.removeAllViews() // Temizle

        if (categoryMap.isEmpty()) {
            val emptyView = TextView(this)
            emptyView.text = "Bu dönemde harcama bulunamadı."
            emptyView.setTextColor(resources.getColor(R.color.text_dark, null))
            emptyView.setPadding(0, 32, 0, 0)
            container.addView(emptyView)
        } else {
            for ((category, amount) in categoryMap) {
                val percentage = (amount / totalExpense) * 100

                // Başlık
                val titleView = TextView(this)
                titleView.text = "$category: $amount TL (%${String.format("%.1f", percentage)})"
                titleView.textSize = 16f
                titleView.setTextColor(resources.getColor(R.color.text_dark, null)) // Temaya uygun renk
                titleView.setPadding(0, 24, 0, 8)

                // Grafik Çubuğu
                val progressBar = LinearProgressIndicator(this)
                progressBar.trackCornerRadius = 10
                progressBar.trackThickness = 20
                progressBar.progress = percentage.toInt()
                progressBar.setIndicatorColor(Color.parseColor("#006C4C"))

                container.addView(titleView)
                container.addView(progressBar)
            }
        }
    }

    // Dönem tarihlerini hesaplayan yardımcı fonksiyon
    private fun getCurrentPeriodDates(prefs: SharedPreferences): Pair<String, String> {
        val startDay = prefs.getInt("StartDay", 15)
        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val startDate: Date
        val endDate: Date

        if (currentDay >= startDay) {
            calendar.set(Calendar.DAY_OF_MONTH, startDay)
            startDate = calendar.time
            calendar.add(Calendar.MONTH, 1)
            endDate = calendar.time
        } else {
            calendar.add(Calendar.MONTH, -1)
            calendar.set(Calendar.DAY_OF_MONTH, startDay)
            startDate = calendar.time
            calendar.add(Calendar.MONTH, 1)
            endDate = calendar.time
        }
        return Pair(sdf.format(startDate), sdf.format(endDate))
    }
}