package com.example.muhasebeapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)

        val rbGroup = findViewById<RadioGroup>(R.id.radioGroupDate)
        val switchDark = findViewById<SwitchMaterial>(R.id.switchDarkMode)
        val btnSave = findViewById<Button>(R.id.btnSaveSettings)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        // 1. Mevcut Ayarları Yükle
        val savedDay = sharedPreferences.getInt("StartDay", 15)
        if (savedDay == 1) {
            rbGroup.check(R.id.rbDay1)
        } else {
            rbGroup.check(R.id.rbDay15)
        }

        val isDarkMode = sharedPreferences.getBoolean("DarkMode", false)
        switchDark.isChecked = isDarkMode

        // 2. Kaydet Butonu
        btnSave.setOnClickListener {
            val editor = sharedPreferences.edit()

            // Tarih Seçimi
            val selectedId = rbGroup.checkedRadioButtonId
            if (selectedId == R.id.rbDay1) {
                editor.putInt("StartDay", 1)
            } else {
                editor.putInt("StartDay", 15)
            }

            // Dark Mode Seçimi
            val darkModeActive = switchDark.isChecked
            editor.putBoolean("DarkMode", darkModeActive)

            editor.apply()

            // Dark Mode'u anında uygula
            if (darkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Toast.makeText(this, "Ayarlar Kaydedildi!", Toast.LENGTH_SHORT).show()
            // Geri dönüldüğünde Splash'in ayarı hatırlaması için activity'i kapatmıyoruz,
            // kullanıcı zaten sonucu görüyor.
        }

        // 3. Çıkış Yap Butonu
        btnLogout.setOnClickListener {
            // Beni Hatırla verisini sil
            val userPrefs = getSharedPreferences("UserPrefs", MODE_PRIVATE)
            val editor = userPrefs.edit()
            editor.clear()
            editor.apply()

            // Login Ekranına Yönlendir ve Geçmişi Sil
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}