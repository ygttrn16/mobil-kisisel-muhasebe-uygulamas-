package com.example.muhasebeapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.muhasebeapp.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var sharedPreferences: SharedPreferences

    private var currentUserId: Int = -1
    private var currentUsername: String = ""
    val categories = arrayOf("yemek", "eğlence", "barınma", "ulaşım", "hobi", "giyim", "sağlık", "eğitim", "sigara", "girdi", "borç", "diğer")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        dbHelper = DatabaseHelper(this)

        currentUserId = intent.getIntExtra("USER_ID", -1)
        currentUsername = intent.getStringExtra("USERNAME") ?: "Kullanıcı"

        if (currentUserId == -1) { finish(); return }

        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        binding.spinnerCategory.adapter = spinnerAdapter

        // --- MENÜ TIKLAMA OLAYLARI ---

        // 1. Ayarlar (Splash üzerinden gider)
        binding.btnSettings.setOnClickListener { goToActivity("SETTINGS") }

        // 2. Geçmiş (Splash üzerinden gider)
        binding.btnGoHistory.setOnClickListener { goToActivity("HISTORY") }

        // 3. Analiz (Splash üzerinden gider)
        binding.btnGoAnalysis.setOnClickListener { goToActivity("ANALYSIS") }

        // 4. Dönem Hareketleri (Splash üzerinden gider + Tarihleri taşır)
        binding.btnGoTransactions.setOnClickListener {
            val (start, end) = getCurrentPeriodDates()

            val intent = Intent(this, SplashActivity::class.java)
            intent.putExtra("TARGET", "TRANSACTIONS")
            intent.putExtra("USER_ID", currentUserId)
            intent.putExtra("START_DATE", start)
            intent.putExtra("END_DATE", end)
            startActivity(intent)
        }

        // 5. Kaydet Butonu
        binding.btnAdd.setOnClickListener { saveRecord() }
    }

    override fun onResume() {
        super.onResume()
        refreshDashboard()
        calculateDaysLeft()
    }

    private fun goToActivity(target: String) {
        val intent = Intent(this, SplashActivity::class.java)
        intent.putExtra("TARGET", target)
        intent.putExtra("USER_ID", currentUserId)
        intent.putExtra("USERNAME", currentUsername)
        startActivity(intent)
    }

    private fun saveRecord() {
        val desc = binding.edtDesc.text.toString()
        val amountStr = binding.edtAmount.text.toString()
        val category = binding.spinnerCategory.selectedItem.toString()

        if (desc.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Lütfen alanları doldurun", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDouble()
        val type = if (binding.rbIncome.isChecked) "girdi" else "cıktı"
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val currentDate = sdf.format(Date())

        if (dbHelper.addTransaction(currentUserId, currentDate, category, desc, amount, type)) {
            Toast.makeText(this, "Kayıt Eklendi", Toast.LENGTH_SHORT).show()
            binding.edtDesc.text?.clear()
            binding.edtAmount.text?.clear()
            refreshDashboard()
        }
    }

    private fun refreshDashboard() {
        val (startDate, endDate) = getCurrentPeriodDates()
        val list = dbHelper.getTransactionsByDateRange(currentUserId, startDate, endDate)

        var totalIncome = 0.0
        var totalExpense = 0.0

        for (item in list) {
            if (item.type == "girdi") totalIncome += item.amount
            else totalExpense += item.amount
        }
        val balance = totalIncome - totalExpense

        binding.txtBalance.text = "${balance} TL"
        binding.txtExpense.text = "${totalExpense} TL"
        binding.txtWelcomeUser.text = "Merhaba, $currentUsername"
    }

    private fun calculateDaysLeft() {
        val (startDate, endDate) = getCurrentPeriodDates()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        try {
            val end = sdf.parse(endDate) ?: Date()
            val today = Date()
            val diff = end.time - today.time
            val daysLeft = TimeUnit.MILLISECONDS.toDays(diff)
            binding.txtDaysLeft.text = "$daysLeft Gün"
        } catch (e: Exception) {
            binding.txtDaysLeft.text = "-- Gün"
        }
    }

    private fun getCurrentPeriodDates(): Pair<String, String> {
        val startDay = sharedPreferences.getInt("StartDay", 15)
        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val startDate: Date
        val endDate: Date

        if (currentDay >= startDay) {
            calendar.set(Calendar.DAY_OF_MONTH, startDay)
            startDate = calendar.time
            calendar.add(Calendar.MONTH, 1)
            endDate = calendar.time
        } else {
            calendar.add(Calendar.MONTH, -1)
            calendar.set(Calendar.DAY_OF_MONTH, startDay)
            startDate = calendar.time
            calendar.add(Calendar.MONTH, 1)
            endDate = calendar.time
        }
        return Pair(sdf.format(startDate), sdf.format(endDate))
    }
}